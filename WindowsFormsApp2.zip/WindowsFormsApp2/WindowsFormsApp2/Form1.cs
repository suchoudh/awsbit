﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();




        }


        public static void WriteLog(string strLog)
        {
            StreamWriter log;
            FileStream fileStream = null;
            DirectoryInfo logDirInfo = null;
            FileInfo logFileInfo;

            string logFilePath = "C:\\Logs\\";
            logFilePath = logFilePath + "Log-" + System.DateTime.Today.ToString("MM-dd-yyyy") + "." + "txt";
            logFileInfo = new FileInfo(logFilePath);
            logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
            if (!logDirInfo.Exists) logDirInfo.Create();
            if (!logFileInfo.Exists)
            {
                fileStream = logFileInfo.Create();
            }
            else
            {
                fileStream = new FileStream(logFilePath, FileMode.Append);
            }
            log = new StreamWriter(fileStream);
            log.WriteLine(strLog);
            log.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WriteLog("Page load started");
            getcountries();
            WriteLog("Page load Ended");

        }

        private void ClearData()
        {
            WriteLog("Clearing the data");
            txtCustomerInfo.Text = "";
            txtCustomerAddress.Text = "";
            cbcountry.Text = "";
            txtCompany.Text = "";
            txtEmail.Text = "";
            txtName.Text = "";
            txtph.Text = "";
            txtSearch.Text = "";

        }
        private void getcountries()
        {
            WriteLog("hitting get countries function");
            System.Net.HttpWebRequest request = WebRequest.Create("https://restcountries.eu/rest/v2/all") as HttpWebRequest;

            string url = "https://restcountries.eu/rest/v2/all";
            WebRequest request12 = HttpWebRequest.Create(url);
            WebResponse response = request12.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string urlText = reader.ReadToEnd(); // it takes the response from your url. now you can use as your need  
            dynamic stuff = JsonConvert.DeserializeObject(urlText);
            WriteLog("loading countries");
            foreach (var s in stuff)
            {
                cbcountry.Items.Add(s.name);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            WriteLog("hitting search button");
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://0esgqqo1i0.execute-api.us-east-1.amazonaws.com/prod");

            httpWebRequest.Method = "POST";
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string s = "{\"Name\": \"" + txtSearch.Text + " \"}";
                var payload = JsonConvert.DeserializeObject(s);
                streamWriter.Write(payload);
                streamWriter.Flush();
                streamWriter.Close();
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {

                    string result = streamReader.ReadToEnd();


                    dynamic dyn = JsonConvert.DeserializeObject(result);
                    string ff = Convert.ToString(dyn.body);
                    dynamic dynn = JsonConvert.DeserializeObject(ff);
                    string fff = Convert.ToString(dynn.details);
                    dynamic stuff = JsonConvert.DeserializeObject(fff);

                    txtName.Text = Convert.ToString(stuff[0].Name);
                    txtCompany.Text = Convert.ToString(stuff[0].companyname);
                    cbcountry.Text = Convert.ToString(stuff[0].country);
                    txtph.Text = Convert.ToString(stuff[0].phone);
                }
            }









            //var connectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            //using (SqlConnection cnn = new SqlConnection(connectionString))
            //{
            //    try
            //    {
            //        cnn.Open();
            //        WriteLog("Connection opened");
            //        Console.WriteLine("Connection Open ! ");
            //        String strQuery = "Select top 1 * from customer where name = '" + txtSearch.Text + "'";
            //        SqlCommand command = new SqlCommand(strQuery, cnn);
            //        using (SqlDataReader reader = command.ExecuteReader())
            //        {
            //            if (reader.Read())
            //            {
            //                WriteLog("inserting new Name : " + reader["Name"]);
            //                txtName.Text = reader["Name"].ToString();
            //                txtCompany.Text = reader["CompanyName"].ToString();
            //                txtEmail.Text = reader["EmailAddress"].ToString();
            //                cbcountry.Text = reader["country"].ToString();
            //                txtph.Text = reader["Phone"].ToString();
            //                txtCustomerAddress.Text = reader["customeraddress"].ToString();
            //                txtCustomerInfo.Text = reader["customerinformation"].ToString();
            //            }
            //            else
            //            {
            //                MessageBox.Show("No records of any customer found with this name. Please provide vaild details");
            //                ClearData();
            //            }
            //        }
            //        cnn.Close();
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine("Can not open connection ! ");
            //    }
        
        //    }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            WriteLog("Insert new data");
            var connectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                try
                {
                    cnn.Open();
                    Console.WriteLine("Connection Open ! ");
                    string StrQuery = "INSERT INTO Customer(Name, CompanyName, EmailAddress, country, Phone, customeraddress,customerinformation) VALUES(@Name, @CompanyName, @EmailAddress, @country, @Phone, @customeraddress,@customerinformation)";
                    SqlCommand command = new SqlCommand(StrQuery, cnn);
                    command.Parameters.AddWithValue("@Name", txtName.Text);
                    command.Parameters.AddWithValue("@CompanyName", txtCompany.Text);
                    command.Parameters.AddWithValue("@EmailAddress", txtEmail.Text);
                    command.Parameters.AddWithValue("@country", cbcountry.Text);
                    command.Parameters.AddWithValue("@Phone", txtph.Text);
                    command.Parameters.AddWithValue("@customeraddress", txtCustomerAddress.Text);
                    command.Parameters.AddWithValue("@customerinformation", txtCustomerInfo.Text);
                    command.ExecuteNonQuery();
                    cnn.Close();
                    MessageBox.Show("The Customer details are added sucessfully!!!!");

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Can not open connection ! ");
                }

            }

























        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearData();
            getcountries();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ClearData();
            getcountries();
        }
    }
}
